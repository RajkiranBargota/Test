﻿using Microsoft.EntityFrameworkCore;

namespace VacoTest.Data
{
    public class ApiDbContext : DbContext
    {

        public ApiDbContext(DbContextOptions<ApiDbContext> options) : base(options) { }

        public DbSet<BlogPost> blogPosts { get; set; }
    }
}
