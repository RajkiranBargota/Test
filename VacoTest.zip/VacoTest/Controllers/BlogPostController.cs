﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using VacoTest.Data;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Linq;

namespace VacoTest.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BlogPostController : ControllerBase
    {
        private readonly ApiDbContext _context;
        //private static readonly string[] Categories = new[]
        //{
        //"General,", "Technology,", "Random"};

        private static List<Category> _categories = new List<Category>
        {
        new Category { Id = 1, Name = "General" },
        new Category { Id = 2, Name = "Technology" },
        new Category { Id = 3, Name = "Random" }
        };

        public BlogPostController(ApiDbContext context)
        {
            _context = context;
        }

        private static List<BlogPost> _blogPosts = new List<BlogPost>
        {
            new BlogPost
            {
                Id = 1,
                Title = "First test Post(General)",
                Contents = "This is the content General.",
                TimeStamp = DateTime.Now,
                Category = 1
            },
            new BlogPost
            {
                Id = 2,
                Title = "Tech Post",
                Contents = "This is a post about technology.",
                TimeStamp = DateTime.Now,
                Category = 2 // Technology
            },
            new BlogPost
            {
                Id = 3,
                Title = "Random Post",
                Contents = "This is a random post.",
                TimeStamp = DateTime.Now,
                Category = 3 // Random
            },
        };

        [HttpGet]
        public async Task<ActionResult<List<BlogPost>>> View()
        {
            return Ok(await _context.blogPosts.ToListAsync());
        }

        [HttpGet("{id}")]
        public ActionResult<BlogPost> View(int id)
        {
            var blogPost = _context.blogPosts.Find(id);

            if (blogPost == null)
            {
                return NotFound();
            }
            return blogPost;

        }

        [HttpPost]
        public async Task<ActionResult<BlogPost>> Create(BlogPost blogPost)
        {
            var Currdate = DateTime.Now;
            blogPost.TimeStamp = Currdate;
            _context.Add(blogPost);
            await _context.SaveChangesAsync();
            return Ok(blogPost);
        }

        [HttpPut("{id}")]

        public async Task<ActionResult<BlogPost>> Edit(int id, BlogPost blogPost)
        {
            if (id != blogPost.Id)
            {
                return BadRequest();
            }
            _context.Entry(blogPost).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return Ok();

        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<BlogPost>> Delete(int id)
        {
            var blogPost = _context.blogPosts.Find(id);
            if (blogPost == null)
            {
                return NotFound();
            }
            _context.blogPosts.Remove(blogPost);
            await _context.SaveChangesAsync();
            return Ok();
        }


        //========Categories========//
        [HttpGet("categories")]
        public ActionResult<IEnumerable<Category>> GetCategories()
        {
            return Ok(_categories);
        }

        [HttpGet("category/{category}")]
        public ActionResult<IEnumerable<BlogPost>> GetByCategory(string category)
        {
            var categoryId = _categories.FirstOrDefault(c => c.Name.Equals(category, StringComparison.OrdinalIgnoreCase))?.Id;
            if (categoryId == null)
            {
                return NotFound($"Category '{category}' not found.");
            }

            var postsInCategory = _blogPosts.Where(p => p.Category == categoryId);
            if (!postsInCategory.Any())
            {
                return NotFound($"No posts found in the category. Please chcek the Categoty name  '{category}'.");
            }

            return Ok(postsInCategory);
        }

    }
}

